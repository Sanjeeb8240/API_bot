// Toggle Password Visibility
document.getElementById('toggle-password').addEventListener('click', function (e) {
    const passwordInput = document.getElementById('api-key-input');
    const eyeIcon = this.querySelector('svg');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"></path>';
    } else {
        passwordInput.type = 'password';
        eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>';
    }
});

// API Key Submission
document.getElementById('set-api-key-btn').addEventListener('click', () => {
    const apiKey = document.getElementById('api-key-input').value;
    const status = document.getElementById('api-key-status');
    fetch('/set_api_key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `api_key=${encodeURIComponent(apiKey)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            status.textContent = data.error;
            status.classList.remove('text-green-600');
            status.classList.add('text-red-600');
        } else {
            status.textContent = data.message;
            status.classList.remove('text-red-600');
            status.classList.add('text-green-600');
            showToast('API key set successfully!', 'success');
            document.getElementById('find-api-btn').disabled = false;
            document.getElementById('fetch-btn').disabled = false;
            document.getElementById('chat-btn').disabled = false;
        }
    })
    .catch(err => {
        status.textContent = 'Error setting API key.';
        status.classList.remove('text-green-600');
        status.classList.add('text-red-600');
        showToast('Error setting API key', 'error');
    });
});

// Initially disable buttons until API key is set
document.getElementById('find-api-btn').disabled = true;
document.getElementById('fetch-btn').disabled = true;
document.getElementById('chat-btn').disabled = true;

// Voice Narration State
let utterance = null;

// Find API Base URL
document.getElementById('find-api-btn').addEventListener('click', () => {
    const websiteUrl = document.getElementById('website-url-input').value;
    const loading = document.getElementById('loading-find');
    loading.classList.remove('hidden');
    fetch('/find_api_url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `website_url=${encodeURIComponent(websiteUrl)}`
    })
    .then(response => response.json())
    .then(data => {
        loading.classList.add('hidden');
        if (data.error) {
            document.getElementById('api-base-url-output').textContent = data.error;
        } else {
            document.getElementById('api-base-url-output').textContent = `API Base URL: ${data.api_base_url}`;
            document.getElementById('api-url-input').value = data.api_base_url;
            showToast('API base URL found!', 'success');
        }
    })
    .catch(err => {
        loading.classList.add('hidden');
        showToast('Error finding API URL', 'error');
    });
});

// Fetch APIs
document.getElementById('fetch-btn').addEventListener('click', () => {
    const apiUrl = document.getElementById('api-url-input').value;
    const loading = document.getElementById('loading-fetch');
    loading.classList.remove('hidden');
    fetch('/fetch_apis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `api_url=${encodeURIComponent(apiUrl)}`
    })
    .then(response => response.json())
    .then(data => {
        loading.classList.add('hidden');
        const apiList = document.getElementById('api-list');
        apiList.innerHTML = '';
        if (data.error) {
            showToast(data.error, 'error');
        } else {
            data.apis.forEach(api => {
                const card = document.createElement('div');
                card.className = 'api-card bg-white p-4 rounded-lg shadow-lg cursor-pointer hover:bg-blue-50';
                card.innerHTML = `
                    <h3 class="text-lg font-semibold text-gray-800">${api}</h3>
                    <p class="text-gray-600 text-sm mt-2">Click to view documentation</p>
                `;
                card.onclick = () => fetchApiDoc(api);
                apiList.appendChild(card);
            });
            showToast('APIs fetched successfully!', 'success');
        }
    })
    .catch(err => {
        loading.classList.add('hidden');
        showToast('Error fetching APIs', 'error');
    });
});

// Fetch API Documentation
function fetchApiDoc(apiUrl) {
    fetch('/get_doc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `api_url=${encodeURIComponent(apiUrl)}`
    })
    .then(response => response.json())
    .then(data => {
        const docContent = document.getElementById('doc-content');
        if (data.error) {
            docContent.innerHTML = data.error;
        } else {
            docContent.innerHTML = data.doc;
            Prism.highlightAll(); // Apply syntax highlighting
            document.getElementById('play-btn').classList.remove('hidden');
            document.getElementById('pause-btn').classList.add('hidden');
            showToast('Documentation loaded!', 'success');
        }
    })
    .catch(err => {
        showToast('Error loading documentation', 'error');
    });
}

// Voice Narration - Play
document.getElementById('play-btn').addEventListener('click', () => {
    const docContent = document.getElementById('doc-content').innerText;
    utterance = new SpeechSynthesisUtterance(docContent);
    utterance.lang = 'en-US';
    utterance.rate = 1;
    speechSynthesis.speak(utterance);
    document.getElementById('play-btn').classList.add('hidden');
    document.getElementById('pause-btn').classList.remove('hidden');
});

// Voice Narration - Pause
document.getElementById('pause-btn').addEventListener('click', () => {
    speechSynthesis.cancel();
    utterance = null;
    document.getElementById('play-btn').classList.remove('hidden');
    document.getElementById('pause-btn').classList.add('hidden');
});

// Chatbot Toggle
document.getElementById('chatbot-toggle').addEventListener('click', () => {
    const chatWindow = document.getElementById('chatbot-window');
    chatWindow.classList.toggle('hidden');
});

// Chatbot Interaction
document.getElementById('chat-btn').addEventListener('click', () => {
    const message = document.getElementById('chat-input').value;
    if (!message) return;
    const chatOutput = document.getElementById('chat-output');
    chatOutput.innerHTML += `<div class="chat-bubble user">${message}</div>`;
    chatOutput.scrollTop = chatOutput.scrollHeight;
    
    const typing = document.getElementById('chat-typing');
    typing.classList.remove('hidden');
    
    fetch('/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `message=${encodeURIComponent(message)}`
    })
    .then(response => response.json())
    .then(data => {
        typing.classList.add('hidden');
        if (data.error) {
            chatOutput.innerHTML += `<div class="chat-bubble bot">${data.error}</div>`;
        } else {
            chatOutput.innerHTML += `<div class="chat-bubble bot">${data.response}</div>`;
        }
        chatOutput.scrollTop = chatOutput.scrollHeight;
    })
    .catch(err => {
        typing.classList.add('hidden');
        showToast('Error with chatbot', 'error');
    });
    document.getElementById('chat-input').value = '';
});

// Theme Toggle
document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

// Toast Notification
function showToast(message, type) {
    const toastContainer = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type === 'success' ? 'bg-green-500' : 'bg-red-500'} text-white px-4 py-2 rounded-lg shadow-lg opacity-0`;
    toast.textContent = message;
    toastContainer.appendChild(toast);
    setTimeout(() => toast.classList.remove('opacity-0'), 100);
    setTimeout(() => {
        toast.classList.add('opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}